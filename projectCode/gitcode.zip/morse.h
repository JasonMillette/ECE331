#ifndef MORSE_H
#define MORSE_H
#include <linux/ioctl.h>

#endif // MORSE_H
