// A. Sheaff SysTimer RPi 2/6/13
// Allow access to sys timer on the RPi

// Minimum header files - module routines and printing
#include <linux/module.h>
#include <linux/kernel.h>

// Entry point after inserting module; Return 0 if successfull
int init_module(void)
{
	printk(KERN_NOTICE "SYSTIMER Found\n");
    return 0;
}

// Executed when modules is removed.
void cleanup_module(void)
{
	printk(KERN_NOTICE "Good Bye\n");
	return;
}
